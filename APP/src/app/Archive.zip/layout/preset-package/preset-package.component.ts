import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preset-package',
  templateUrl: './preset-package.component.html',
  styleUrls: ['./preset-package.component.scss']
})
export class PresetPackageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
