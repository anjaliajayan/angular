import { CreatePackageComponent } from './create-package.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreatePackageRoutingModule } from './create-package-routing.module';


@NgModule({
  declarations: [CreatePackageComponent],
  imports: [
    CommonModule,
    CreatePackageRoutingModule
  ]
})
export class CreatePackageModule { }
