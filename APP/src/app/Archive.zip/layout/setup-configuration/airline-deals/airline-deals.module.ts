import { AirlineDealsComponent } from './airline-deals.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AirlineDealsRoutingModule } from './airline-deals-routing.module';


@NgModule({
  declarations: [AirlineDealsComponent],
  imports: [
    CommonModule,
    AirlineDealsRoutingModule
  ]
})
export class AirlineDealsModule { }
