import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-airline-deals',
  templateUrl: './airline-deals.component.html',
  styleUrls: ['./airline-deals.component.scss']
})
export class AirlineDealsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
