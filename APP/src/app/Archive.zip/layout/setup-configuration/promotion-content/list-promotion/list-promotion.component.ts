import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-promotion',
  templateUrl: './list-promotion.component.html',
  styleUrls: ['./list-promotion.component.scss']
})
export class ListPromotionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
