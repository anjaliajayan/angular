import { CreatePromotionComponent } from './create-promotion/create-promotion.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {
    path: '',
    component: CreatePromotionComponent,
    children: [
      { path: '', redirectTo: 'create-promotion', pathMatch: 'prefix' },
      { path: 'create-promotion', loadChildren: () => import('./create-promotion/create-promotion.module').then(m => m.CreatePromotionModule) },
      { path: 'list-promotion', loadChildren: () => import('./list-promotion/list-promotion.module').then(m => m.ListPromotionModule) }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PromotionContentRoutingModule { }
