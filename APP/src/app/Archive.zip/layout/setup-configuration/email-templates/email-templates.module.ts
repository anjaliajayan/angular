import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmailTemplatesRoutingModule } from './email-templates-routing.module';
import { EmailTemplatesComponent } from './email-templates.component';


@NgModule({
  declarations: [EmailTemplatesComponent],
  imports: [
    CommonModule,
    EmailTemplatesRoutingModule
  ]
})
export class EmailTemplatesModule { }
