import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-currency-configuration',
  templateUrl: './currency-configuration.component.html',
  styleUrls: ['./currency-configuration.component.scss']
})
export class CurrencyConfigurationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
