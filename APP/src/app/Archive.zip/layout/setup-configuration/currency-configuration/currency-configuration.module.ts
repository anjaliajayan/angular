import { CurrencyConfigurationComponent } from './currency-configuration.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CurrencyConfigurationRoutingModule } from './currency-configuration-routing.module';


@NgModule({
  declarations: [CurrencyConfigurationComponent],
  imports: [
    CommonModule,
    CurrencyConfigurationRoutingModule
  ]
})
export class CurrencyConfigurationModule { }
