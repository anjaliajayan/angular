import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-management',
  templateUrl: './content-management.component.html',
  styleUrls: ['./content-management.component.scss']
})
export class ContentManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
