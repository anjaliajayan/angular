import { ContentManagementComponent } from './content-management.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContentManagementRoutingModule } from './content-management-routing.module';


@NgModule({
  declarations: [ContentManagementComponent],
  imports: [
    CommonModule,
    ContentManagementRoutingModule
  ]
})
export class ContentManagementModule { }
