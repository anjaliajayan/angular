import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setup-configuration',
  templateUrl: './setup-configuration.component.html',
  styleUrls: ['./setup-configuration.component.scss']
})
export class SetupConfigurationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
