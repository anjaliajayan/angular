import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-markup-configuration',
  templateUrl: './markup-configuration.component.html',
  styleUrls: ['./markup-configuration.component.scss']
})
export class MarkupConfigurationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
