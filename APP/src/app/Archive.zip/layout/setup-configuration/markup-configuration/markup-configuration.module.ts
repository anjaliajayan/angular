import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MarkupConfigurationRoutingModule } from './markup-configuration-routing.module';
import { MarkupConfigurationComponent } from './markup-configuration.component';


@NgModule({
  declarations: [MarkupConfigurationComponent],
  imports: [
    CommonModule,
    MarkupConfigurationRoutingModule
  ]
})
export class MarkupConfigurationModule { }
