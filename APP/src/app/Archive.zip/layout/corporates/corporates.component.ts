import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corporates',
  templateUrl: './corporates.component.html',
  styleUrls: ['./corporates.component.scss']
})
export class CorporatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
