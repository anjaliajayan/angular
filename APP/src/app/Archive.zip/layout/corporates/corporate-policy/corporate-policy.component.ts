import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corporate-policy',
  templateUrl: './corporate-policy.component.html',
  styleUrls: ['./corporate-policy.component.scss']
})
export class CorporatePolicyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
