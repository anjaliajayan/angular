import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approval-queues',
  templateUrl: './approval-queues.component.html',
  styleUrls: ['./approval-queues.component.scss']
})
export class ApprovalQueuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
