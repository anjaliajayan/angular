import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-point-sales-management',
  templateUrl: './point-sales-management.component.html',
  styleUrls: ['./point-sales-management.component.scss']
})
export class PointSalesManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
