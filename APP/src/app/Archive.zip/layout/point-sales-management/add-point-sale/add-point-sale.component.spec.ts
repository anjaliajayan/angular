import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPointSaleComponent } from './add-point-sale.component';

describe('AddPointSaleComponent', () => {
  let component: AddPointSaleComponent;
  let fixture: ComponentFixture<AddPointSaleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPointSaleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPointSaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
