import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-point-sale',
  templateUrl: './add-point-sale.component.html',
  styleUrls: ['./add-point-sale.component.scss']
})
export class AddPointSaleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
