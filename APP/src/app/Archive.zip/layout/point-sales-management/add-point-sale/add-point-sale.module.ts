import { AddPointSaleComponent } from './add-point-sale.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddPointSaleRoutingModule } from './add-point-sale-routing.module';


@NgModule({
  declarations: [AddPointSaleComponent],
  imports: [
    CommonModule,
    AddPointSaleRoutingModule
  ]
})
export class AddPointSaleModule { }
