import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddPointSaleComponent } from './add-point-sale.component';


const routes: Routes = [
  {path: '', component: AddPointSaleComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AddPointSaleRoutingModule { }
