import { PointSalesManagementComponent } from './point-sales-management.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PointSalesManagementRoutingModule } from './point-sales-management-routing.module';


@NgModule({
  declarations: [PointSalesManagementComponent],
  imports: [
    CommonModule,
    PointSalesManagementRoutingModule
  ]
})
export class PointSalesManagementModule { }
