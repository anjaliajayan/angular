import { PointSalesManagementComponent } from './point-sales-management.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {
    path: '',
    component: PointSalesManagementComponent,
    children: [
      { path: '', redirectTo: 'add-point-sale', pathMatch: 'prefix' },
      { path: 'add-point-sale', loadChildren: () => import('./add-point-sale/add-point-sale.module').then(m => m.AddPointSaleModule) },
      { path: 'list-point-sale', loadChildren: () => import('./list-point-sale/list-point-sale.module').then(m => m.ListPointSaleModule) }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PointSalesManagementRoutingModule { }
