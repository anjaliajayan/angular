import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ListPointSaleRoutingModule } from './list-point-sale-routing.module';
import { ListPointSaleComponent } from './list-point-sale.component';


@NgModule({
  declarations: [ListPointSaleComponent],
  imports: [
    CommonModule,
    ListPointSaleRoutingModule
  ]
})
export class ListPointSaleModule { }
