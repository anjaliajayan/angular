import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListPointSaleComponent } from './list-point-sale.component';

describe('ListPointSaleComponent', () => {
  let component: ListPointSaleComponent;
  let fixture: ComponentFixture<ListPointSaleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListPointSaleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListPointSaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
