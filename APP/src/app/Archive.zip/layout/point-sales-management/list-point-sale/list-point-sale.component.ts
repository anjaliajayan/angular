import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-point-sale',
  templateUrl: './list-point-sale.component.html',
  styleUrls: ['./list-point-sale.component.scss']
})
export class ListPointSaleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
