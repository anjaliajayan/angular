import { Component, OnInit } from '@angular/core';

declare var Chartist:any;

@Component({
  selector: 'app-graphs',
  templateUrl: './graphs.component.html',
  styleUrls: ['./graphs.component.scss']
})
export class GraphsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    setTimeout(() => this.displayChart(), 200);
  }

  displayChart() {
    let chart = new Chartist.Line('.ct-chart', {
      labels: ['13 August, 2019'],
      series: [
        [12, 9, 7, 8, 5],
        [2, 1, 3.5, 7, 3],
        [1, 3, 4, 5, 6]
      ]
    }, {
      fullWidth: true,
      chartPadding: {
        right: 40
      }
    });
  }
}
