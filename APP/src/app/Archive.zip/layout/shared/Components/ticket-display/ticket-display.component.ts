import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ticket-display',
  templateUrl: './ticket-display.component.html',
  styleUrls: ['./ticket-display.component.scss']
})
export class TicketDisplayComponent implements OnInit {
  @Input()tabNumber;
  constructor() { }

  ngOnInit() {
  }

}
