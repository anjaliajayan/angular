import { Component, OnInit, Input ,ViewEncapsulation, EventEmitter, Output, AfterViewInit} from '@angular/core';
import { FlightDataService } from '../../../../shared/services/flight-data.service';

import { FormControl, FormGroup, FormArray, ControlContainer } from '@angular/forms';
import { Observable, Subscription,timer } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { trigger, transition, style, animate } from '@angular/animations';

import {Router, ActivatedRoute} from '@angular/router';


@Component({
  selector: 'app-mat-sub',
  templateUrl: './mat-sub.component.html',
  styleUrls: ['./mat-sub.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger(
      'inOutAnimation', 
      [
        transition(
          ':enter', 
          [
            style({ height: 0, opacity: 0 }),
            animate('0.1s ease-out', 
                    style({ height: 229, opacity: 1 }))
          ]
        ),
        transition(
          ':leave', 
          [
            style({ height: 229, opacity: 1 }),
            animate('0.1s ease-in', 
                    style({ height: 0, opacity: 0 }))
          ]
        )
      ]
    )
  ],
})
export class MatSubComponent implements OnInit {
  @Input()tabNumber;
  submitted=false;
  showLoader: boolean = false;
  private subscription: Subscription;
  private timer: Observable<any>;

  subOptions=[true];
  pAirlines=["Emirates","Air India","Saudi Gulf","Oman Air","My Airline"];

  array: string[] = [];
  agents = ['Diera Agent','London Agent','TPBC','4connects'];
  clients = ['Umer','Syed','Aswani'];
  preferredClass = ['Econonmy','Business','First Class'];
  selectedStatus = "3";
  
  multiCity=0;

 
  constructor(private flightdataService: FlightDataService) { 

  }


  flightSearchForm:FormGroup;
 
  options: string[] = ['Dubai', 'London', 'Washington DC'];
  filteredDepartures: Observable<string[]>;
  filteredArrivals: Observable<string[]>;
  filteredAgents:Observable<string[]>;
  filteredClients:Observable<string[]>;
  filteredClass:Observable<string[]>;


  selectTab($event){
    this.tabNumber++;

  }


  populateDropdown(index) {
    this.filteredDepartures = this.getformArray.controls[index].get('departures').valueChanges
      .pipe(
        map(value => this._filter(value))
      );
      this.filteredArrivals = this.getformArray.controls[index].get('arrivals').valueChanges
      .pipe(
        map(value => this._filter(value))
      );
  }

  get getformArray() {
    return this.flightSearchForm.get('multiFormArray') as FormArray;
  }


  ngOnInit() {
   this.subOptions[0]=true;
   
    let multiFormArray = new FormArray([]);
    
    for(let i=0;i<this.multiCity;i++){
      multiFormArray.push(
        new FormGroup({
          departures: new FormControl(),
          arrivals: new FormControl(),
          departureDates: new FormControl(),
          
        })
      )
    }
    this.flightSearchForm = new FormGroup({
      departure: new FormControl(),
      arrival: new FormControl(),
      economy: new FormControl(),
      departureDate: new FormControl(),
      agents: new FormControl(),
      clients: new FormControl(),
      range: new FormControl(),
      nonStop:new FormControl(),
      preferredClass: new FormControl(),
      multiFormArray: multiFormArray
    });
   

    this.filteredDepartures = this.flightSearchForm.get('departure').valueChanges
      .pipe(
        map(value => this._filter(value))
      );
      this.filteredArrivals = this.flightSearchForm.get('arrival').valueChanges
      .pipe(
        map(value => this._filter(value))
      ); 
      this.filteredAgents = this.flightSearchForm.get('agents').valueChanges
      .pipe(
        map(value => this.getAgent(value))
      ); 
      this.filteredClients = this.flightSearchForm.get('clients').valueChanges
      .pipe(
        map(value => this.getClient(value))
      ); 
      this.filteredClass = this.flightSearchForm.get('preferredClass').valueChanges
      .pipe(
        map(value => this.getClass(value))
      ); 
      this.popFromArray(this.selectedStatus);
  }

  addCity(){
    
    if(this.getformArray.length<6){
        this.multiCity=this.multiCity+1;

        (<FormArray>this.flightSearchForm.get('multiFormArray')).push(
          new FormGroup({
            departures: new FormControl(),
            arrivals: new FormControl(),
            departureDates: new FormControl(),
          })
        )
  }

  }
  changeSub(val){
    this.subOptions[val]=!this.subOptions[val];
  }
  popFromArray(val){
    this.selectedStatus=val;
    const temp = this.getformArray;
    temp.clear();
    if(val!=='2'){
      (<FormArray>this.flightSearchForm.get('multiFormArray')).push(
        new FormGroup({
          departures: new FormControl(),
          arrivals: new FormControl(),
          departureDates: new FormControl(),
        })
      )
    }
    else{
      (<FormArray>this.flightSearchForm.get('multiFormArray')).push(
        new FormGroup({
          departures: new FormControl(),
          arrivals: new FormControl(),
          departureDates: new FormControl(),
          economy:new FormControl()
        })
      )
    }

    // while (temp.length-2) {
    //   temp.removeAt(0);
    // }
      // if(this.selectedStatus!=='3'){
    //   for(i=1;i<temp.length;i++){
    //     console.log(i);
    //     temp.removeAt(i);
    //   }
    // }

  }
  removeCity(index){
    if(this.getformArray.length>1){
      const temp=this.getformArray;
      temp.removeAt(index);
    }
  }

  sendRequest = () => {
    
    this.showLoader   = true;
    console.log(this.showLoader);
    this.timer        = timer(5000); // 5000 millisecond means 5 seconds
    this.subscription = this.timer.subscribe(() => {
        // set showloader to false to hide loading div from view after 5 seconds
        this.showLoader = false;
        console.log(this.showLoader);
        this.submitted = true;
    });
 
    //this.router.navigate(['/search/flights/submit']);
   
    
    this.flightdataService.FlightDataPost(null,this.tabNumber).subscribe();
  }
  private getAgent(value:string){
    const filterValue = value.toLowerCase();
    return this.agents.filter(option=>option.toLowerCase().includes(filterValue));
  }
  private getClient(value:string){
    const filterValue = value.toLowerCase();
    return this.clients.filter(option=>option.toLowerCase().includes(filterValue));
  }
  private getClass(value:string){
    const filterValue = value.toLowerCase();
    return this.preferredClass.filter(option=>option.toLowerCase().includes(filterValue));
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    this.flightdataService.getDropDown(filterValue).subscribe(res => {
      return this.options.filter(() => {
        if(res) {
          this.array=[];
          for(let r in res){this.array.push(res[r]['label']);}
        }
        return this.array;
      });
    });
    return this.array
  }

}
