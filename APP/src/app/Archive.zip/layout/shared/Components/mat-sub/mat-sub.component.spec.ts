import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MatSubComponent } from './mat-sub.component';

describe('MatSubComponent', () => {
  let component: MatSubComponent;
  let fixture: ComponentFixture<MatSubComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MatSubComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatSubComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
