import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iur',
  templateUrl: './iur.component.html',
  styleUrls: ['./iur.component.scss']
})
export class IurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
