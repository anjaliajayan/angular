import { FloatingDepositsComponent } from './floating-deposits.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FloatingDepositsRoutingModule } from './floating-deposits-routing.module';


@NgModule({
  declarations: [FloatingDepositsComponent],
  imports: [
    CommonModule,
    FloatingDepositsRoutingModule
  ]
})
export class FloatingDepositsModule { }
