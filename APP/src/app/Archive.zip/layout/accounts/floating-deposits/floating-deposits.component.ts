import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-floating-deposits',
  templateUrl: './floating-deposits.component.html',
  styleUrls: ['./floating-deposits.component.scss']
})
export class FloatingDepositsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
