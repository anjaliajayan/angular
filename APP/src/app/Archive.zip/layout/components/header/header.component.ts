import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  
  toggleSidebar() {
    $('.ui.sidebar').sidebar('setting', 'dimPage', false).sidebar('toggle');
  }

  ngAfterViewInit() {
    $('.ui.dropdown').dropdown();
  }

}
