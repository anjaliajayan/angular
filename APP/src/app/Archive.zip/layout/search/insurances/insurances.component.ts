import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurances',
  templateUrl: './insurances.component.html',
  styleUrls: ['./insurances.component.scss']
})
export class InsurancesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
