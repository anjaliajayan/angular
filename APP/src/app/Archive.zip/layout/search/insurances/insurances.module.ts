import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InsurancesRoutingModule } from './insurances-routing.module';
import { InsurancesComponent } from './insurances.component';


@NgModule({
  declarations: [InsurancesComponent],
  imports: [
    CommonModule,
    InsurancesRoutingModule
  ]
})
export class InsurancesModule { }
