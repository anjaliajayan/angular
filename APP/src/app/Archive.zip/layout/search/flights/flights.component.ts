import { FlightSearchService } from './../../../shared/services/flight-search.service';
import { FlightDataService } from '../../../shared/services/flight-data.service';
import { Component, OnInit, Input, Inject } from '@angular/core';
import { FormControl, FormGroup, FormArray, FormBuilder } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import Swal from 'sweetalert2';

declare const $:any;
declare const owlCarousel:any;
import {Router, ActivatedRoute} from '@angular/router';

export interface DialogData {
  animal: 'panda' | 'unicorn' | 'lion';
}

@Component({
  selector: 'app-flights',
  templateUrl: './flights.component.html',
  styleUrls: ['./flights.component.scss']
})

export class FlightsComponent implements OnInit {
  tabsArray = [];
  airportsArray: any = [];
  flightResults: [] = [];
  searchLoader: boolean = false;
  searchBoxCard: boolean = true;
  searchResultsCard: boolean = false;
  flightSearchObj:any = {};
  minDate = new Date();
  flightResultsMsg = '';
  airportsLoader = false;
  bookFlights = false;

  constructor(private flightdataService: FlightDataService,
    private flightSearchService: FlightSearchService,
    private fb: FormBuilder,
    private router:Router,
    private dialog: MatDialog
    ) { }

  flightSearchForm = this.fb.group({
    searchType: [''],
    departure: [''],
    arrival: [''],
    departureDate: [''],
    returnDate: [''],
    currency: [''],
    ptc: [''],
    age: [''],
    cabinType: [''],
    multiDestination: this.fb.array([])
  });

  options: any = [{code: '', label: ''}];
  filteredDepartures: Observable<any>;
  filteredArrivals: Observable<any>;

  initMultiDestinations() {
    return this.fb.group({
      departure: [''],
      departureDate: [''],
      arrival: ['']
    });
  }

  get multiDest():any {
    return this.flightSearchForm.get('multiDestination') as FormArray;
  }

  addMultiDest() {
    this.multiDest.push(this.initMultiDestinations());
  }

  removeMultiDest(index) {
    if(index > 0) this.multiDest.removeAt(index);
  }

  removeAllMultiDest() {
    this.flightSearchForm.get('multiDestination').patchValue(this.fb.array([]));
  }

  bookFlight() {
    this.bookFlights = true;
    this.searchResultsCard = false;
  }

  filterDepartures(index) {
    console.log(this.multiDest.controls[index]);
    this.filteredDepartures = this.multiDest.controls[index].controls.departure.valueChanges
    .pipe(
      startWith(''),
      map((value:any) => this._filter(value))
    );
  }

  filterArrivals(index) {
    console.log(this.multiDest.controls[index]);
    this.filteredArrivals = this.multiDest.controls[index].controls.arrival.valueChanges
    .pipe(
      startWith(''),
      map((value:any) => this._filter(value))
    );
  }

  openFareBaggageDetails() {
    this.flightSearchService.fetchFareBaggageDetails().subscribe((fare:any) => {
      if(fare.data) {
        this.dialog.open(DialogFareBaggageDetails, {
          data: fare.data
        });
      }
    }, (err) => {
      Swal.fire('Oops', `Something bad happened at our end. ${err}`, 'error');
    });
  }

  ngOnInit() {
    this.addTab();
    this.fetchAirports();
    
    this.filteredDepartures = this.flightSearchForm.get('departure').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );
      this.filteredArrivals = this.flightSearchForm.get('arrival').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      ); 
    
      setTimeout(() => {
        $('.owl-carousel').owlCarousel({
          loop:true,
          margin:10,
          nav:true,
          responsive:{
              0:{
                  items:1
              },
              600:{
                  items:3
              },
              1000:{
                  items:4
              }
          }
        });
      }, 1200);
  }

  fetchAirports() {
    this.airportsLoader = true;
    this.flightSearchService.airportsListing().subscribe((res:any) => {
      if(res) {
        this.airportsArray=[];
        if(res.airports !== undefined && res.airports.length) {
          res.airports.forEach(r => {
            this.airportsArray.push({ code: r.airport_code, label: r.airport_name})
          });
          this.airportsLoader = false; 
        } else {
          this.fetchAirports();
        }
      }
    },(err:any) => {
      Swal.fire('Oops...', 'Error: Something went wrong at our end. We apologise for inconvenience.', 'error');
      this.airportsLoader = false;
    });
  }

  searchFlights = () => {
    this.flightSearchObj.searchType = this.flightSearchForm.get('searchType').value;
    if(this.flightSearchObj.searchType == 'multiple') {
      this.flightSearchObj.multiDest = this.flightSearchForm.get('multiDestination').value;
      console.log(this.flightSearchObj);
    } else {
      this.flightSearchObj.departure = this.flightSearchForm.get('departure').value;
      this.flightSearchObj.arrival = this.flightSearchForm.get('arrival').value;
      this.flightSearchObj.departureDate = this.flightSearchForm.get('departureDate').value;
      this.flightSearchObj.returnDate = this.flightSearchForm.get('returnDate').value;
    }
    this.flightSearchObj.currency = 'GBP';
    this.flightSearchObj.ptc = 'ADT';
    this.flightSearchObj.age = '30';
    this.flightSearchObj.cabinType = 'Y';

    this.searchLoader = true;
    this.searchBoxCard = false;

    console.log(this.flightSearchObj);

    this.flightSearchService.searchFlight(this.flightSearchObj)
      .subscribe((results:any) => {
        if(!results.json.hasOwnProperty('type')) {
          this.flightResults = results.json.FlightDetails;
          this.searchResultsCard = true;
          this.searchLoader = false;
          this.searchBoxCard = true;
          this.flightResultsMsg = '';
        } else {
          console.log(results);
          this.flightResultsMsg = results.json.msg;
          this.searchLoader = false;
          this.searchBoxCard = true;
        }
    })
  }

  displayAirportName(airport?): string | undefined {
    return airport ? airport.label : undefined;
  }

  private _filter(value: string): string[] {
    if(value !== undefined && value.length > 2) {
      // const temp = Object.assign(this.airportsArray);
      const filterValue = value.toLowerCase();
      return this.airportsArray.filter(option => option.label.toLowerCase().includes(filterValue));
    }
  }
  tabNumber=0;
  submitted=[];
  
  addTab() { this.tabsArray.push({ name: 'Search Flights', label: this.tabNumber, icon: 'clear' }) }
  
  removeTab(index) {
    if (index > 0)
      this.tabsArray.splice(index, 1);
    return;
  }

  selectTab($event) { this.tabNumber++; }
}

@Component({
  selector: 'dialog-fare-baggage-details',
  templateUrl: 'fare-baggage-details/dialog-fare-baggage-details.html',
})
export class DialogFareBaggageDetails {
  constructor(@Inject(MAT_DIALOG_DATA) public data: DialogData) {}
}
