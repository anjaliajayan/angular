import { FlightsComponent } from './flights.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {MatSubComponent } from '../../shared/Components/mat-sub/mat-sub.component'
import {TicketDisplayComponent} from '../../shared/Components/ticket-display/ticket-display.component'

const outletObj = [];
const routes: Routes = [
  {
    path: '',
    component: FlightsComponent,
    children: [
      { path: '', component: MatSubComponent },
      { path: 'submit', component: TicketDisplayComponent},
      
      ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlightsRoutingModule {
  populateChildren() {
    for(let i=1; i<= 6; i++) {
      outletObj.push()
    }
  }

  constructor() {
    this.populateChildren();
  }
}
