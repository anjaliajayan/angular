import { MatBottomSheetModule } from '@angular/material/bottom-sheet';
import { MatButtonModule } from '@angular/material/button';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FlightsRoutingModule } from './flights-routing.module';
import {MatCardModule} from '@angular/material/card';
import {MatTabsModule} from '@angular/material/tabs';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {MatRadioModule} from '@angular/material/radio';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatSelectModule} from '@angular/material/select';
import {MatListModule} from '@angular/material/list';
import { MatIconModule } from '@angular/material';
import {MatSubComponent} from '../../shared/Components/mat-sub/mat-sub.component';
import {TicketDisplayComponent} from '../../shared/Components/ticket-display/ticket-display.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { RouterModule } from '@angular/router';
import {FlightDataService} from '../../../shared/services/flight-data.service'
import { FlightSearchService } from './../../../shared/services/flight-search.service';
import { FlightsComponent, DialogFareBaggageDetails } from './flights.component';
import { BookFlightsComponent, FarePriceConditionsSheet } from './book-flights/book-flights.component';

@NgModule({
  entryComponents: [FarePriceConditionsSheet, DialogFareBaggageDetails],
  declarations: [FlightsComponent, FarePriceConditionsSheet, BookFlightsComponent, MatSubComponent, TicketDisplayComponent, DialogFareBaggageDetails],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FlightsRoutingModule,
    MatCardModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    MatRadioModule,
    MatGridListModule,
    MatDatepickerModule,
    MatSelectModule,
    MatButtonModule,
    MatListModule,
    MatBottomSheetModule,
    MatSelectModule,
    MatDatepickerModule,
    FlexLayoutModule,
    MatCheckboxModule,
    MatIconModule,
    RouterModule, 
  ],
  providers:[
    FlightDataService,
    FlightSearchService
  ]
})
export class FlightsModule { }
