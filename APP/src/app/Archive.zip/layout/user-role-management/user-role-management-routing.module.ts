import { UserRoleManagementComponent } from './user-role-management.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {
    path: '',
    component: UserRoleManagementComponent,
    children: [
      { path: '', redirectTo: 'create-user', pathMatch: 'prefix' },
      { path: 'create-user', loadChildren: () => import('./create-user/create-user.module').then(m => m.CreateUserModule) },
      { path: 'list-user', loadChildren: () => import('./list-user/list-user.module').then(m => m.ListUserModule) },
      { path: 'update-profile', loadChildren: () => import('./update-profile/update-profile.module').then(m => m.UpdateProfileModule) }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoleManagementRoutingModule { }
