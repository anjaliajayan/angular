import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-role-management',
  templateUrl: './user-role-management.component.html',
  styleUrls: ['./user-role-management.component.scss']
})
export class UserRoleManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
